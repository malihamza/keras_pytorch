class Constants:
    TQDM_TRAINING_BAR_CHARACTER = " >="
    TQDM_VAL_BAR_CHARACTER = " >-"
    TQDM_UNIT = " batch"
